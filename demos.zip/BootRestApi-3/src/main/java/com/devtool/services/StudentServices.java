package com.devtool.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.devtool.entities.Student;
import com.devtool.repository.StudentRepository;


@Component
public class StudentServices {

	@Autowired
	private StudentRepository studentRepository;
	
	
	
	  private static List<Student> list=new ArrayList<>();
	  
	  static {
	  
	  list.add(new Student(1, "JS","mumbai")); list.add(new Student(2, "CSS","nagar"));
	  list.add(new Student(3, "Perl","pune"));
	  
	  }
	 

	
	public List<Student> getAllStudents()
	{
		
		List<Student> list=(List<Student>)this.studentRepository.findAll();
		//return list;
		
		return list;
	}
	
	// get single student
	public Student getStudentById(int id)
	{
		Student student=null;
		
		try {
		
	    student= this.studentRepository.findById(id);
		   }
	   catch(Exception e)
		{
		//   System.out.println(e.getMessage());
	
		e.printStackTrace();
		}
	   
	   return student;
	}
	
	
	//Adding a student
	public Student addStudent(Student b)
	{
	//	list.add(b);
	  Student student=  studentRepository.save(b);
	  
		return student;
	}
	
	// Updating student by id
	
	public void updateStudentById(Student student,int id)
	{
		
		student.setId(id);
		studentRepository.save(student);
	}
	
	// Deleting student by id 
	
	public void deleteStudent(int id)
	{
  
		
		 studentRepository.deleteById(id);
	
	}
	
}
