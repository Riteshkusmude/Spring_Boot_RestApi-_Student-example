package com.devtool.repository;

import org.springframework.data.repository.CrudRepository;

import com.devtool.entities.Student;

public interface StudentRepository extends CrudRepository<Student,Integer> {

	 public Student findById(int id);
	 
}
