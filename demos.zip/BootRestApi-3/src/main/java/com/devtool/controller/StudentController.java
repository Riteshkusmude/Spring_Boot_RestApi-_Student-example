package com.devtool.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.devtool.entities.Student;
import com.devtool.services.StudentServices;

@RestController
public class StudentController {

	@Autowired
	private StudentServices studentServices;
	
	@GetMapping(value = "/students")
	public ResponseEntity<List<Student>> getStudents()
	{
		
		
	     List<Student> list= studentServices.getAllStudents();
		
	     if(list.size()<=0)
	     {
	    	 return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	     }
	     return ResponseEntity.of(Optional.of(list));
		
		
	}
	
	// Student by id 
	
	@GetMapping(value = "/students/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable("id") int id)
	{
		

		Student student= this.studentServices.getStudentById(id);
		
		if(student==null)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		return ResponseEntity.of(Optional.of(student));
	
	}
	
	// Adding Student into the list
	
	@PostMapping(value = "/students")
	public ResponseEntity<Student> addStudent(@RequestBody Student student)
	{
		Student b=null;
		
		try
		{
		  b= this.studentServices.addStudent(student);
		  System.out.println(b);
		  return ResponseEntity.of(Optional.of(b));
		
		}
		catch(Exception e)
		{
			e.printStackTrace();

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		
	}
	
	// Updating value of Student by id 
	
	
	  @PutMapping(value = "/students/{id}")
	  
	  public Student updateStudent(@RequestBody Student student,@PathVariable("id") int id) {
		   this.studentServices.updateStudentById(student,id);
	    return student;
	  }
	 
	
	// Deleting student by id
	
	@DeleteMapping(value ="/students/{id}")
	
	public void deleteStudent(@PathVariable("id")int id)
	{
	
		  this.studentServices.deleteStudent(id);
		
	}
	
	// Jsp example
	
	@RequestMapping(value = "/")
	public String home()
	{
		
		return "home.jsp";
	}
	
}
