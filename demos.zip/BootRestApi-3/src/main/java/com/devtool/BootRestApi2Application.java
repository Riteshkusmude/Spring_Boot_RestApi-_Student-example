package com.devtool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootRestApi2Application {

	public static void main(String[] args) {
		SpringApplication.run(BootRestApi2Application.class, args);
	}

}
